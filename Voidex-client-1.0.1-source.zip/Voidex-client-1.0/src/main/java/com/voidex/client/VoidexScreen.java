package com.voidex.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public class VoidexScreen extends Screen {
    private int page = 0;
    private int waitingForBind = -1;
    private static final int PURPLE = 0xFF9B59FF;
    private static final int PANEL = 0xF014111C;
    private static final int ROW = 0xFF211B2A;
    private static final String[] TABS = {"PvP", "Visuals", "Cosmetics", "Utils", "Key Binds"};
    private static final String[] BIND_NAMES = {
            "Target HUD", "Damage Indicator", "Combo Counter", "Hit Color", "Hit Particles",
            "Armor HUD", "Potions Counter", "Crosshair Editor", "View Model"
    };
    private static final int[] BIND_DEFAULTS = {
            GLFW.GLFW_KEY_T, GLFW.GLFW_KEY_I, GLFW.GLFW_KEY_K, GLFW.GLFW_KEY_H, GLFW.GLFW_KEY_J,
            GLFW.GLFW_KEY_B, GLFW.GLFW_KEY_P, GLFW.GLFW_KEY_C, GLFW.GLFW_KEY_V
    };

    public VoidexScreen() { super(Component.literal("VØIDEX")); }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        this.renderBackground(g, mouseX, mouseY, delta);
        int w = 470, h = 300;
        int left = (width - w) / 2, top = (height - h) / 2;
        g.fill(left - 1, top - 1, left + w + 1, top + h + 1, 0xFF9B59FF);
        g.fill(left, top, left + w, top + h, PANEL);
        g.fill(left, top, left + w, top + 3, PURPLE);

        g.drawString(font, "VØIDEX", left + 18, top + 14, 0xFFF1E6FF, false);
        g.drawString(font, "CLIENT 1.0", left + 18, top + 29, 0xFFAA91C8, false);
        g.drawString(font, "RIGHT SHIFT", left + w - 105, top + 19, 0xFFBFA6D8, false);
        g.fill(left + 145, top + 48, left + 146, top + h - 18, 0xFF493653);

        for (int i = 0; i < TABS.length; i++) {
            int y = top + 58 + i * 39;
            boolean selected = page == i;
            g.fill(left + 12, y, left + 134, y + 30, selected ? 0xFF51316D : ROW);
            if (selected) g.fill(left + 12, y, left + 15, y + 30, PURPLE);
            g.drawString(font, TABS[i], left + 25, y + 11, selected ? 0xFFFFFFFF : 0xFFD0C5D8, false);
        }

        int contentX = left + 164;
        g.drawString(font, TABS[page], contentX, top + 57, 0xFFEADFFF, false);
        g.fill(contentX, top + 75, left + w - 18, top + 76, 0xFF493653);

        if (page == 0) {
            drawFeatureRows(g, contentX, top + 88, new String[]{"Target HUD", "Damage Indicator", "Combo Counter", "Hit Color", "Hit Particles"}, 0);
        } else if (page == 1) {
            drawFeatureRows(g, contentX, top + 88, new String[]{"Armor HUD", "Potions Counter", "Crosshair Editor", "View Model", "Edit HUD position"}, 5);
        } else if (page == 2 || page == 3) {
            g.drawCenteredString(font, "Coming Soon", left + 307, top + 151, 0xFFB98AE8);
            g.drawCenteredString(font, "Новые функции появятся позже", left + 307, top + 169, 0xFF8F829B);
        } else {
            drawKeyBinds(g, contentX, top + 86);
        }

        if (waitingForBind >= 0) {
            g.fill(left + 154, top + h - 35, left + w - 12, top + h - 12, 0xFF39234D);
            g.drawCenteredString(font, "Нажми клавишу для " + BIND_NAMES[waitingForBind] + "  •  ESC отмена", left + 318, top + h - 27, 0xFFFFFFFF);
        } else {
            g.drawString(font, "VØIDEX  •  Visual Client", left + 18, top + h - 25, 0xFF8F829B, false);
            g.drawString(font, "ESC  Закрыть", left + w - 95, top + h - 25, 0xFF8F829B, false);
        }
        super.render(g, mouseX, mouseY, delta);
    }

    private void drawFeatureRows(GuiGraphics g, int x, int y, String[] names, int offset) {
        for (int i = 0; i < names.length; i++) {
            int ry = y + i * 34;
            g.fill(x, ry, width / 2 + 205, ry + 28, ROW);
            g.drawString(font, names[i], x + 10, ry + 10, 0xFFF0EAF5, false);
            if (offset == 0) drawToggle(g, width / 2 + 169, ry + 9, getFeature(offset + i));
            else if (i < 4) drawToggle(g, width / 2 + 169, ry + 9, getFeature(offset + i));
            else g.drawString(font, "OPEN", width / 2 + 165, ry + 10, 0xFFD4A9FF, false);
        }
    }

    private void drawKeyBinds(GuiGraphics g, int x, int y) {
        g.fill(x, y, width / 2 + 205, y + 19, ROW);
        g.drawString(font, "Open Menu", x + 8, y + 6, 0xFFF0EAF5, false);
        g.fill(width / 2 + 112, y + 2, width / 2 + 200, y + 17, 0xFF493653);
        g.drawCenteredString(font, "Right Shift", width / 2 + 156, y + 5, 0xFFEADFFF);
        for (int i = 0; i < BIND_NAMES.length; i++) {
            int ry = y + 22 + i * 22;
            g.fill(x, ry, width / 2 + 205, ry + 19, ROW);
            g.drawString(font, BIND_NAMES[i], x + 8, ry + 6, 0xFFF0EAF5, false);
            String key = waitingForBind == i ? "Нажми..." : keyName(VoidexClient.CONFIG.keyBinds[i]);
            int bx = width / 2 + 112;
            g.fill(bx, ry + 2, bx + 88, ry + 17, 0xFF493653);
            g.drawCenteredString(font, key, bx + 44, ry + 5, 0xFFEADFFF);
        }
    }

    private boolean getFeature(int i) {
        return switch (i) {
            case 0 -> VoidexClient.CONFIG.targetHud;
            case 1 -> VoidexClient.CONFIG.damageIndicator;
            case 2 -> VoidexClient.CONFIG.comboCounter;
            case 3 -> VoidexClient.CONFIG.hitColor;
            case 4 -> VoidexClient.CONFIG.hitParticles;
            case 5 -> VoidexClient.CONFIG.armorHud;
            case 6 -> VoidexClient.CONFIG.potionsHud;
            case 7 -> VoidexClient.CONFIG.crosshairEditor;
            case 8 -> VoidexClient.CONFIG.viewModel;
            default -> false;
        };
    }

    private void drawToggle(GuiGraphics g, int x, int y, boolean on) {
        g.fill(x, y, x + 25, y + 10, on ? 0xFF8950C8 : 0xFF514B58);
        g.fill(on ? x + 15 : x + 2, y + 2, on ? x + 23 : x + 10, y + 8, 0xFFFFFFFF);
    }

    private static String keyName(int key) {
        if (key == GLFW.GLFW_KEY_UNKNOWN) return "Не назначена";
        return InputConstants.getKey(key, 0).getDisplayName().getString();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int w = 470, h = 300, left = (width - w) / 2, top = (height - h) / 2;
        if (button == 0) {
            if (mouseX >= left + 12 && mouseX <= left + 134 && mouseY >= top + 58 && mouseY < top + 58 + TABS.length * 39) {
                page = Math.min(TABS.length - 1, Math.max(0, (int) ((mouseY - (top + 58)) / 39)));
                waitingForBind = -1;
                return true;
            }
            if (page == 0 || page == 1) {
                int index = (int) ((mouseY - (top + 88)) / 34);
                if (index >= 0 && index < 5 && mouseX >= left + 164 && mouseX <= left + w - 18) {
                    int feature = (page == 0 ? 0 : 5) + index;
                    if (page == 1 && index == 4) minecraft.setScreen(new VoidexHudEditorScreen());
                    else { VoidexClient.toggleFeature(feature); VoidexClient.CONFIG.save(); }
                    return true;
                }
            } else if (page == 4) {
                int index = (int) ((mouseY - (top + 108)) / 22);
                if (index >= 0 && index < BIND_NAMES.length && mouseX >= left + 164) {
                    waitingForBind = index;
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (waitingForBind >= 0) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) waitingForBind = -1;
            else {
                VoidexClient.CONFIG.keyBinds[waitingForBind] = keyCode == GLFW.GLFW_KEY_BACKSPACE ? GLFW.GLFW_KEY_UNKNOWN : keyCode;
                VoidexClient.CONFIG.save();
                waitingForBind = -1;
            }
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public boolean isPauseScreen() { return false; }
}
