# VØIDEX Client 1.0

A client-side Fabric mod project for Minecraft 1.21.11.

## Menu
- Open the centered VØIDEX menu with **Right Shift**.
- Sidebar tabs: PvP, Visuals, Cosmetics, Utils, Key Binds.
- Cosmetics and Utils currently show Coming Soon.
- Key Binds lists Open Menu and the current feature keys. Click a key field, then press a key to rebind it. Backspace clears a binding; Escape cancels.
- Feature key bindings are saved in `config/voidex.properties`.

Default feature keys:
- Target HUD: T
- Damage Indicator: I
- Combo Counter: K
- Hit Color: H
- Hit Particles: J
- Armor HUD: B
- Potions Counter: P
- Crosshair Editor: C
- View Model: V

## Build
Use Java 21 and Gradle, then run `gradle build`. The remapped mod jar is generated in `build/libs/`.

This is an early source prototype. The current implemented baseline includes the centered menu, saved key binds, nearest-player Target HUD, movable Target HUD editor, armor durability HUD, and active-effect timers. Damage Indicator, Combo Counter, Hit Color, Hit Particles, Crosshair Editor, and View Model are currently menu/config placeholders and are not fully implemented. The source has not yet been compiled or tested in-game.
