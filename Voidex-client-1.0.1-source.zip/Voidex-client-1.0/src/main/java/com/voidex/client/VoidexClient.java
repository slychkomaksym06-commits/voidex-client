package com.voidex.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import java.util.HashSet;
import java.util.Set;

public class VoidexClient implements ClientModInitializer {
    public static final String MOD_ID = "voidex";
    public static final VoidexConfig CONFIG = new VoidexConfig();
    private static KeyMapping openMenuKey;
    private static final Set<Integer> heldBindKeys = new HashSet<>();

    @Override
    public void onInitializeClient() {
        CONFIG.load();

        KeyMapping.Category category = KeyMapping.Category.register(
                ResourceLocation.fromNamespaceAndPath(MOD_ID, "main")
        );
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.voidex.open_menu",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new VoidexScreen());
                }
            }
            pollFeatureBinds(client);
            CONFIG.tickTarget(client);
        });

        HudRenderCallback.EVENT.register((graphics, deltaTracker) -> renderHud(graphics));
    }


    private static void pollFeatureBinds(Minecraft client) {
        if (client.getWindow() == null) return;
        long window = client.getWindow().getWindow();
        for (int i = 0; i < CONFIG.keyBinds.length; i++) {
            int key = CONFIG.keyBinds[i];
            if (key == GLFW.GLFW_KEY_UNKNOWN) continue;
            boolean down = GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
            if (down && heldBindKeys.add(key)) {
                if (client.screen == null) {
                    toggleFeature(i);
                    CONFIG.save();
                }
            } else if (!down) {
                heldBindKeys.remove(key);
            }
        }
    }

    public static void toggleFeature(int index) {
        switch (index) {
            case 0 -> CONFIG.targetHud = !CONFIG.targetHud;
            case 1 -> CONFIG.damageIndicator = !CONFIG.damageIndicator;
            case 2 -> CONFIG.comboCounter = !CONFIG.comboCounter;
            case 3 -> CONFIG.hitColor = !CONFIG.hitColor;
            case 4 -> CONFIG.hitParticles = !CONFIG.hitParticles;
            case 5 -> CONFIG.armorHud = !CONFIG.armorHud;
            case 6 -> CONFIG.potionsHud = !CONFIG.potionsHud;
            case 7 -> CONFIG.crosshairEditor = !CONFIG.crosshairEditor;
            case 8 -> CONFIG.viewModel = !CONFIG.viewModel;
        }
    }

    private static void renderHud(GuiGraphics graphics) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null || client.options.hideGui) return;

        int x = CONFIG.hudX;
        int y = CONFIG.hudY;

        if (CONFIG.targetHud) {
            Player target = CONFIG.currentTarget;
            if (target != null) {
                renderTargetHud(graphics, target, x, y);
            }
        }

        if (CONFIG.armorHud) {
            renderArmorHud(graphics, client, client.getWindow().getGuiScaledWidth() - 104,
                    client.getWindow().getGuiScaledHeight() - 92);
        }

        if (CONFIG.potionsHud) {
            renderPotions(graphics, client, 8, 8);
        }
    }

    public static void renderTargetHud(GuiGraphics g, Player target, int x, int y) {
        Minecraft mc = Minecraft.getInstance();
        int width = 174;
        int height = 48;
        float hp = Math.max(0, target.getHealth());
        float maxHp = Math.max(1, target.getMaxHealth());
        int barWidth = (int) ((width - 58) * (hp / maxHp));

        g.fill(x, y, x + width, y + height, 0xE916141D);
        g.fill(x, y, x + width, y + 1, 0xFF9B59FF);
        g.fill(x, y + height - 1, x + width, y + height, 0xFF9B59FF);
        g.fill(x, y, x + 1, y + height, 0xFF9B59FF);
        g.fill(x + width - 1, y, x + width, y + height, 0xFF9B59FF);

        // Compact avatar tile; player skin rendering can be added without changing the HUD layout.
        g.fill(x + 7, y + 7, x + 39, y + 39, 0xFF352344);
        String initial = target.getGameProfile().getName().isEmpty()
                ? "?" : target.getGameProfile().getName().substring(0, 1).toUpperCase();
        g.drawCenteredString(mc.font, initial, x + 23, y + 18, 0xFFE7D5FF);

        g.drawString(mc.font, target.getGameProfile().getName(), x + 46, y + 10, 0xFFFFFFFF, false);
        g.fill(x + 46, y + 27, x + width - 7, y + 34, 0xFF382D43);
        if (barWidth > 0) {
            g.fill(x + 46, y + 27, x + 46 + barWidth, y + 34, 0xFFAA68FF);
        }
        String hpText = String.format(java.util.Locale.ROOT, "%.1f HP", hp);
        g.drawString(mc.font, hpText, x + width - mc.font.width(hpText) - 7, y + 10, 0xFFE6CFFF, false);
    }

    private static void renderArmorHud(GuiGraphics g, Minecraft mc, int x, int y) {
        if (mc.player == null) return;
        String[] labels = {"H", "C", "L", "B"};
        for (int i = 0; i < 4; i++) {
            ItemStack stack = mc.player.getInventory().armor.get(3 - i);
            int rowY = y + i * 20;
            g.fill(x, rowY, x + 96, rowY + 18, 0xB916141D);
            g.drawString(mc.font, labels[i], x + 4, rowY + 5, 0xFFD8B8FF, false);
            if (!stack.isEmpty()) {
                g.renderItem(stack, x + 20, rowY + 1);
                int percent = stack.isDamageableItem()
                        ? Math.max(0, 100 - (int) (100.0 * stack.getDamageValue() / stack.getMaxDamage()))
                        : 100;
                g.drawString(mc.font, percent + "%", x + 43, rowY + 5, 0xFFFFFFFF, false);
            } else {
                g.drawString(mc.font, "--", x + 43, rowY + 5, 0xFF888888, false);
            }
        }
        ItemStack main = mc.player.getMainHandItem();
        ItemStack off = mc.player.getOffhandItem();
        drawHeldItem(g, mc, main, x, y + 82, "R");
        drawHeldItem(g, mc, off, x, y + 102, "L");
    }

    private static void drawHeldItem(GuiGraphics g, Minecraft mc, ItemStack stack, int x, int y, String label) {
        g.fill(x, y, x + 96, y + 18, 0xB916141D);
        g.drawString(mc.font, label, x + 4, y + 5, 0xFFD8B8FF, false);
        if (!stack.isEmpty()) {
            g.renderItem(stack, x + 20, y + 1);
            int percent = stack.isDamageableItem()
                    ? Math.max(0, 100 - (int) (100.0 * stack.getDamageValue() / stack.getMaxDamage()))
                    : 100;
            g.drawString(mc.font, percent + "%", x + 43, y + 5, 0xFFFFFFFF, false);
        } else {
            g.drawString(mc.font, "--", x + 43, y + 5, 0xFF888888, false);
        }
    }

    private static void renderPotions(GuiGraphics g, Minecraft mc, int x, int y) {
        if (mc.player == null) return;
        int row = 0;
        for (MobEffectInstance effect : mc.player.getActiveEffects()) {
            String name = effect.getEffect().value().getDisplayName().getString();
            int seconds = Math.max(0, effect.getDuration() / 20);
            String timer = String.format(java.util.Locale.ROOT, "%d:%02d", seconds / 60, seconds % 60);
            g.fill(x, y + row * 18, x + 142, y + row * 18 + 16, 0xB916141D);
            g.drawString(mc.font, name, x + 5, y + row * 18 + 4, 0xFFEADFFF, false);
            g.drawString(mc.font, timer, x + 142 - mc.font.width(timer) - 5,
                    y + row * 18 + 4, 0xFFCE9CFF, false);
            row++;
            if (row >= 8) break;
        }
    }

    public static class VoidexConfig {
        public boolean targetHud = true;
        public boolean armorHud = true;
        public boolean potionsHud = true;
        public boolean damageIndicator = true;
        public boolean comboCounter = false;
        public boolean hitColor = false;
        public boolean hitParticles = false;
        public boolean crosshairEditor = true;
        public boolean viewModel = false;
        public int hudX = 12;
        public int hudY = 42;
        public int targetRadius = 5;
        public int[] keyBinds = {GLFW.GLFW_KEY_T, GLFW.GLFW_KEY_I, GLFW.GLFW_KEY_K, GLFW.GLFW_KEY_H,
                GLFW.GLFW_KEY_J, GLFW.GLFW_KEY_B, GLFW.GLFW_KEY_P, GLFW.GLFW_KEY_C, GLFW.GLFW_KEY_V};
        public Player currentTarget;

        private Path file() {
            return FabricLoader.getInstance().getConfigDir().resolve("voidex.properties");
        }

        public void load() {
            Path path = file();
            if (!Files.exists(path)) return;
            Properties p = new Properties();
            try (var in = Files.newInputStream(path)) {
                p.load(in);
                targetHud = Boolean.parseBoolean(p.getProperty("targetHud", "true"));
                armorHud = Boolean.parseBoolean(p.getProperty("armorHud", "true"));
                potionsHud = Boolean.parseBoolean(p.getProperty("potionsHud", "true"));
                damageIndicator = Boolean.parseBoolean(p.getProperty("damageIndicator", "true"));
                comboCounter = Boolean.parseBoolean(p.getProperty("comboCounter", "false"));
                hitColor = Boolean.parseBoolean(p.getProperty("hitColor", "false"));
                hitParticles = Boolean.parseBoolean(p.getProperty("hitParticles", "false"));
                crosshairEditor = Boolean.parseBoolean(p.getProperty("crosshairEditor", "true"));
                viewModel = Boolean.parseBoolean(p.getProperty("viewModel", "false"));
                hudX = Integer.parseInt(p.getProperty("hudX", "12"));
                hudY = Integer.parseInt(p.getProperty("hudY", "42"));
                for (int i = 0; i < keyBinds.length; i++) {
                    keyBinds[i] = Integer.parseInt(p.getProperty("keyBind" + i, Integer.toString(keyBinds[i])));
                }
            } catch (Exception ignored) {
                // Defaults are retained if the config file is invalid.
            }
        }

        public void save() {
            Properties p = new Properties();
            p.setProperty("targetHud", Boolean.toString(targetHud));
            p.setProperty("armorHud", Boolean.toString(armorHud));
            p.setProperty("potionsHud", Boolean.toString(potionsHud));
            p.setProperty("damageIndicator", Boolean.toString(damageIndicator));
            p.setProperty("comboCounter", Boolean.toString(comboCounter));
            p.setProperty("hitColor", Boolean.toString(hitColor));
            p.setProperty("hitParticles", Boolean.toString(hitParticles));
            p.setProperty("crosshairEditor", Boolean.toString(crosshairEditor));
            p.setProperty("viewModel", Boolean.toString(viewModel));
            p.setProperty("hudX", Integer.toString(hudX));
            p.setProperty("hudY", Integer.toString(hudY));
            for (int i = 0; i < keyBinds.length; i++) p.setProperty("keyBind" + i, Integer.toString(keyBinds[i]));
            try {
                Files.createDirectories(file().getParent());
                try (var out = Files.newOutputStream(file())) {
                    p.store(out, "VØIDEX client settings");
                }
            } catch (IOException ignored) {
                // The game remains usable if settings cannot be saved.
            }
        }

        public void tickTarget(Minecraft client) {
            currentTarget = null;
            if (!targetHud || client.player == null || client.level == null) return;
            double best = targetRadius * targetRadius;
            for (Player candidate : client.level.players()) {
                if (candidate == client.player || candidate.isSpectator() || !candidate.isAlive()) continue;
                double distance = client.player.distanceToSqr(candidate);
                if (distance <= best) {
                    best = distance;
                    currentTarget = candidate;
                }
            }
        }
    }
}
