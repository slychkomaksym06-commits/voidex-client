package com.voidex.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class VoidexHudEditorScreen extends Screen {
    private boolean dragging;
    private int dragOffsetX;
    private int dragOffsetY;

    public VoidexHudEditorScreen() {
        super(Component.literal("VØIDEX HUD Editor"));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        this.renderBackground(g, mouseX, mouseY, delta);
        g.drawCenteredString(font, "HUD EDITOR  •  Drag the preview", width / 2, 24, 0xFFE7D5FF);
        if (minecraft.player != null) {
            VoidexClient.renderTargetHud(g, minecraft.player, VoidexClient.CONFIG.hudX, VoidexClient.CONFIG.hudY);
        }
        g.drawCenteredString(font, "ESC = save and close", width / 2, height - 28, 0xFFBFA6D8);
        super.render(g, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mouseX = event.x();
        double mouseY = event.y();
        int button = event.button();
        if (button == 0) {
            int x = VoidexClient.CONFIG.hudX;
            int y = VoidexClient.CONFIG.hudY;
            if (mouseX >= x && mouseX <= x + 174 && mouseY >= y && mouseY <= y + 48) {
                dragging = true;
                dragOffsetX = (int) mouseX - x;
                dragOffsetY = (int) mouseY - y;
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        double mouseX = event.x();
        double mouseY = event.y();
        int button = event.button();
        if (dragging && button == 0) {
            VoidexClient.CONFIG.hudX = Math.max(0, Math.min(width - 174, (int) mouseX - dragOffsetX));
            VoidexClient.CONFIG.hudY = Math.max(0, Math.min(height - 48, (int) mouseY - dragOffsetY));
            return true;
        }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        int button = event.button();
        if (button == 0 && dragging) {
            dragging = false;
            VoidexClient.CONFIG.save();
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
